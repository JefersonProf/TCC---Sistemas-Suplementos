// Alternar resposta (abre/fecha com + e -)
const questions = document.querySelectorAll(".faq-question");

questions.forEach(q => {
  q.addEventListener("click", () => {
    const parent = q.parentElement;
    parent.classList.toggle("open");

    // Alternar ícone +/-
    const icon = q.querySelector(".icon");
    icon.textContent = parent.classList.contains("open") ? "−" : "+";
  });
});

// Filtros de categoria
const filterBtns = document.querySelectorAll(".filter-btn");
const faqItems = document.querySelectorAll(".faq-item");

filterBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    // remover destaque dos outros botões
    filterBtns.forEach(b => b.classList.remove("active"));
    btn.classList.add("active");

    const category = btn.dataset.category;

    faqItems.forEach(item => {
      if (item.dataset.category === category) {
        item.classList.add("active");
      } else {
        item.classList.remove("active", "open");
        item.querySelector(".icon").textContent = "+";
      }
    });
  });
});
