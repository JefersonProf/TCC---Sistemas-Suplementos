document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    const cartCount = document.querySelector('.cart-count');

    // Menu responsivo
    menuToggle.addEventListener('click', function () {
        navLinks.classList.toggle('active');
    });

    function updateCartCount(count) {
        cartCount.textContent = count;
    }

    // FILTRO POR CATEGORIA
    const categorySelect = document.querySelector(".category-select");
    const sortSelect = document.querySelector(".sort-select");
    const productsGrid = document.querySelector(".products-grid");
    const productCards = Array.from(productsGrid.querySelectorAll(".product-card"));

    categorySelect.addEventListener("change", function () {
        const selectedCategory = categorySelect.value;

        productCards.forEach(card => {
            if (!card.dataset.category) {
                card.dataset.category = "all"; // evita erro
            }
            card.style.display = (selectedCategory === "all" || card.dataset.category === selectedCategory) ? "block" : "none";
        });
    });

    // ORDENAÇÃO DE PRODUTOS
    sortSelect.addEventListener("change", function () {
        const sortValue = sortSelect.value;
        const visibleCards = productCards.filter(card => card.style.display !== "none");

        let sortedCards = [...visibleCards];

        if (sortValue === "price-asc") {
            sortedCards.sort((a, b) => {
                const priceA = parseFloat(a.querySelector(".product-price").textContent.replace(/[^\d,]/g, "").replace(",", "."));
                const priceB = parseFloat(b.querySelector(".product-price").textContent.replace(/[^\d,]/g, "").replace(",", "."));
                return priceA - priceB;
            });
        } else if (sortValue === "price-desc") {
            sortedCards.sort((a, b) => {
                const priceA = parseFloat(a.querySelector(".product-price").textContent.replace(/[^\d,]/g, "").replace(",", "."));
                const priceB = parseFloat(b.querySelector(".product-price").textContent.replace(/[^\d,]/g, "").replace(",", "."));
                return priceB - priceA;
            });
        } else {
            sortedCards = productCards; // voltar à ordem original
        }

        // Reorganizar no DOM
        productsGrid.innerHTML = "";
        sortedCards.forEach(card => productsGrid.appendChild(card));
    });
});


